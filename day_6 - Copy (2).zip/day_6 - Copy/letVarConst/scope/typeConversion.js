let strToNum="34" +34;
console.log("strToNum:",strToNum);
console.log("type of strToNum:",typeof strToNum);

//number to string
let numToStr=34+"34";
console.log("number to string:",numToStr);
console.log("type of numToStr:",typeof numToStr);

let a ="23"+23+(-67)+"67"+true-false;
console.log(type of a);
console.log("type of NaN" ,typeof NaN);
console.log("type of null" ,typeof null);
console.log("type of NULL" ,typeof NULL);
console.log("type of Null" ,typeof Null);
console.log("type of undefined:" ,typeof undefined);
console.log("Explicit Type Conservation:");
console.log(Boolean("123"),Boolean("123"));
console.log(Boolean(""),Boolean("") );
console.log(Boolean(null),Boolean(null) );
console.log(Boolean(-1),Boolean(-1));
console.log(Boolean(0),Boolean(0));