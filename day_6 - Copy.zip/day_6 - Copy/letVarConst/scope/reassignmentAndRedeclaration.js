var a= 30;
var a=60;
a=45;
console.log(a);

//let
let b=56;
b=54;
console.log(b);

const pi=3.14;
console.log(pi);