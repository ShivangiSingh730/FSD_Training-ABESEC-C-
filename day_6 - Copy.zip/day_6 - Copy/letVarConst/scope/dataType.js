let name="xyz";
let age=23;
let boolVal=false;
console.log("name:",name);
console.log("age:",age);
console.log("boolean value:",boolVal);