console.log("Hello from  html file");
document.writeln("Hello from html file with 'writeln()'");
// alert("this is a alert message.");
console.error("error message");